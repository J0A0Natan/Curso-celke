<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Celke - Administrativo</title>
    </head>
    <body>
        <?php 
            require './core/ConfigController.php';
            $home = new ConfigController();
        ?>
    </body>
</html>