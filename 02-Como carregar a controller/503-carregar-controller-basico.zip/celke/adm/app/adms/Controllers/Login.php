<?php

class Login
{
    public function index()
    {
        echo "Pagina de login<br>";
    }
}