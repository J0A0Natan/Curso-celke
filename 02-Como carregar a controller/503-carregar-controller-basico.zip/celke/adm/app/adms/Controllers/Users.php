<?php

class Users
{
    public function index()
    {
        echo "Pagina listar usuarios<br>";
    }
}