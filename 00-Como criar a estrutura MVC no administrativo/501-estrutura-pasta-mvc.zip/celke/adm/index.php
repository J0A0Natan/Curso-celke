<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Celke - Administrativo</title>
    </head>
    <body>
        <?php echo "Bem vindo ao ADM!"; ?>
    </body>
</html>